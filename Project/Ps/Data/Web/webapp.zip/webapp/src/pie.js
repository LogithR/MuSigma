import React from 'react';
import pieall from '../pieall.PNG';
import barall from '../barall.PNG';
import downall1 from '../downall1.PNG';
import downall2 from '../downall2.PNG';
import downall3 from '../downall3.PNG';

function ImageBox() {
  return (
    <div style={{ position: 'absolute', top: '15%', width: '100%' }}>
      <div style={{ display: 'flex', justifyContent: 'center' }}>
        <div style={{
          width: '100%',
          maxWidth: '500px',
          height: '320px',
          borderRadius: '10px',
          overflow: 'hidden',
          boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
          textAlign: 'center',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          marginLeft: '200px',
        }}>
          <img 
            src={pieall} 
            alt="Pie Chart"
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'contain',
            }} 
          />
        </div>

        <div style={{
          width: '1150px',
          height: '320px',
          borderRadius: '10px',
          overflow: 'hidden',
          boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
          textAlign: 'center',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          marginLeft: '30px',
          
        }}>
          <img 
            src={barall} 
            alt="Bar Chart"
            style={{
              width: '1100px',
              height: '100%',
            }} 
          />
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'center' }}>
        <div style={{
          width: '400px',
          height: '320px',
          borderRadius: '10px',
          overflow: 'hidden',
          boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
          textAlign: 'center',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          margin: '20px',
        }}>
          <img 
            src={downall1} 
            alt="Rectangle 1"
            style={{
              width: '140%',
              height: '100%',
              objectFit: 'contain',
            }} 
          />
        </div>

        <div style={{
          width: '450px',
          height: '320px',
          borderRadius: '10px',
          overflow: 'hidden',
          boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
          textAlign: 'center',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          margin: '20px',
        }}>
          <img 
            src={downall2} 
            alt="Rectangle 2"
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'contain',
            }} 
          />
        </div>

        <div style={{
          width: '450px',
          height: '320px',
          borderRadius: '10px',
          overflow: 'hidden',
          boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
          textAlign: 'center',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          margin: '20px',
        }}>
          <img 
            src={downall3} 
            alt="Rectangle 3"
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'contain',
            }} 
          />
        </div>
      </div>
    </div>
  );
}

export default ImageBox;
