import React from "react";
import logo from "../Picture1.png";

const header = () => {
  return (
    <div>
      <div style={{ display: "flex" }}>
        <img
          src={logo}
          alt="Logo"
          style={{ width: "55px", padding: "2px 41px" }}
        ></img>
        <div
          style={{
            backgroundColor: "rgb(128, 0, 0)",
            color: "White",
            fontWeight: "bold",
            fontSize: "35px",
            width: "100%",
            textAlign: "Center",
            alignItems: "center",
            marginTop:'-7px'
          }}
        >
          <span style={{ position: "relative",fontSize:'20px'

          }}>
            Hotel Booking Demand
          </span>
        </div>
      </div>
    </div>
  );
};

export default header;
