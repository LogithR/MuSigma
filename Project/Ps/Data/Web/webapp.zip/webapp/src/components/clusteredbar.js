import React, { useEffect, useState } from "react";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import Papa from "papaparse";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const ClusteredBarChart = ({ selectedOption, selectedOption2, setIsLoading }) => {
  const [data, setData] = useState({ labels: [], datasets: [] });

  useEffect(() => {
    setIsLoading(true); // Start loader when data fetch begins

    fetch("/cleaned_hotel_bookings.csv")
      .then((response) => response.text())
      .then((csvData) => {
        Papa.parse(csvData, {
          header: true,
          complete: (results) => {
            const marketSegmentCount = {};

            results.data.forEach((row) => {
              const segment = row["arrival_date_month"];
              const hotel = row["hotel"];
              const arrivalYear = row["arrival_date_year"];

              if (
                (selectedOption === "" || hotel === selectedOption) &&
                (selectedOption2 === "" || arrivalYear === selectedOption2)
              ) {
                if (segment) {
                  marketSegmentCount[segment] =
                    (marketSegmentCount[segment] || 0) + 1;
                }
              }
            });

            const monthOrder = [
              "January",
              "February",
              "March",
              "April",
              "May",
              "June",
              "July",
              "August",
              "September",
              "October",
              "November",
              "December",
            ];

            const labels = monthOrder.filter(
              (month) => marketSegmentCount[month] !== undefined
            );
            const values = labels.map(
              (month) => marketSegmentCount[month] || 0
            );

            setData({
              labels: labels,
              datasets: [
                {
                  label: selectedOption || "All Hotels",
                  data: values,
                  backgroundColor: "#36A2EB",
                  borderColor: "rgba(66, 165, 245, 1)",
                  borderWidth: 1,
                },
              ],
            });

            setIsLoading(false); // Stop loader after data is loaded
          },
        });
      });
  }, [selectedOption, selectedOption2, setIsLoading]);

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    indexAxis: "y",
    plugins: {
      title: {
        display: true,
        text: 'Bookings By Month',
        font: { size: 15 },
      },
      tooltip: {
        callbacks: {
          label: function (context) {
            let label = context.dataset.label || "";
            if (label) {
              label += ": ";
            }
            label += context.raw;
            return label;
          },
        },
      },
      legend: {
        display: true,
        position: "right",
        labels: {
          boxWidth: 10,
        },
      },
    },
    scales: {
      x: {
        title: {
          display: true,
          text: "Number of Bookings",
        },
      },
      y: {
        title: {
          display: true,
          text: "Months",
        },
      },
    },
  };

  return (
    <div
      style={{
        width: "826px",
        height: "250px",
        marginLeft: "34.2%",
        marginTop: "-19.5%",
        marginBottom: '19px',
        backgroundColor: 'rgb(243,244,245)',
      }}
    >
      <Bar data={data} options={options} />
    </div>
  );
};

export default ClusteredBarChart;
