import React, { useEffect, useState } from "react";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import Papa from "papaparse";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const StackedColumnChart = ({
  selectedOption,
  selectedOption2,
  xColumn,
  yColumn,
  setIsLoading, // Accept setIsLoading function as a prop
}) => {
  const [data, setData] = useState({ labels: [], datasets: [] });

  useEffect(() => {
    setIsLoading(true); // Set loader to true when data fetching starts

    fetch("/cleaned_hotel_bookings.csv")
      .then((response) => response.text())
      .then((csvData) => {
        Papa.parse(csvData, {
          header: true,
          complete: (results) => {
            const aggregatedData = {};

            results.data.forEach((row) => {
              const xValue = row["lead_time"];
              const option = row["hotel"];
              const option2 = row["arrival_date_year"];

              if (
                (selectedOption === "" || option === selectedOption) &&
                (selectedOption2 === "" || option2 === selectedOption2) &&
                xValue
              ) {
                if (!aggregatedData[xValue]) {
                  aggregatedData[xValue] = 0;
                }
                aggregatedData[xValue] += 1;
              }
            });

            const sortedEntries = Object.entries(aggregatedData)
              .sort(([, a], [, b]) => b - a)
              .slice(0, 10); // Only keep top 10 values

            const labels = sortedEntries.map(([xValue]) => xValue);
            const datasetValues = sortedEntries.map(([, count]) => count);

            setData({
              labels: labels,
              datasets: [
                {
                  label: `No of Bookings`,
                  data: datasetValues,
                  backgroundColor: "#36A2EB",
                  borderColor: "rgba(66, 165, 245, 1)",
                  borderWidth: 1,
                },
              ],
            });

            setIsLoading(false); // Hide the loader when data is ready
          },
        });
      });
  }, [selectedOption, selectedOption2, xColumn, yColumn, setIsLoading]);

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      title: {
        display: true,
        text: `No of Bookings respect to Lead Time`,
        font: { size: 15 },
      },
      tooltip: {
        callbacks: {
          label: function (context) {
            let label = context.dataset.label || "";
            if (label) {
              label += ": ";
            }
            label += context.raw;
            return label;
          },
        },
      },
      legend: { display: true, position: "top" },
    },
    scales: {
      x: {
        title: {
          display: true,
          text: "Lead Time (Days)",
        },
      },
      y: {
        title: {
          display: true,
          text: "Count",
        },
        stacked: true,
      },
    },
  };

  return (
    <div style={{ height: "245px", marginLeft: '4.5px', marginTop: "-15px", backgroundColor: 'rgb(243,244,245)' }}>
      <Bar data={data} options={options} style={{ width: "340px" }} />
    </div>
  );
};

export default StackedColumnChart;