import React, { useEffect, useState } from "react";
import Papa from "papaparse";

const Slicer2 = ({ onOptionChange2, isLoading, setIsLoading }) => {
  const [allOptions2, setAllOptions2] = useState([]);

  useEffect(() => {
    setIsLoading(true);
    fetch("/cleaned_hotel_bookings.csv")
      .then((response) => response.text())
      .then((csvData) => {
        Papa.parse(csvData, {
          header: true,
          complete: (results) => {
            const optionSet2 = new Set();

            results.data.forEach((row) => {
              const option2 = row["arrival_date_year"];
              if (option2) {
                optionSet2.add(option2);
              }
            });

            setAllOptions2([...optionSet2]);
            setIsLoading(false); 
          },
        });
      });
  }, [setIsLoading]);

  return (
    <div style={{ marginBottom: "20px", marginLeft: "10px" }}>
      <h2 style={{ marginLeft: "35px", fontSize: "20px" }}>Year</h2>
      <select
        onChange={(e) => {
          setIsLoading(true); 
          onOptionChange2(e); 
        }}
        style={{
          padding: "5px",
          fontSize: "10px",
          width: "8%",
          marginLeft: "10px",
        }}
      >
        <option value="">All</option>
        {allOptions2.map((option2, index) => (
          <option key={index} value={option2}>
            {option2}
          </option>
        ))}
      </select>
    </div>
  );
};

export default Slicer2;
