import React, { useEffect, useState } from "react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import Papa from "papaparse";

ChartJS.register(
  CategoryScale,
  LinearScale,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend
);

const DynamicLineChart = ({ selectedOption, selectedOption2, xColumn, yColumn, setIsLoading }) => {
  const [data, setData] = useState({ labels: [], datasets: [] });

  useEffect(() => {
    setIsLoading(true); // Show loader when fetching starts

    fetch("/cleaned_hotel_bookings.csv")
      .then((response) => response.text())
      .then((csvData) => {
        Papa.parse(csvData, {
          header: true,
          complete: (results) => {
            const monthData = {};

            results.data.forEach((row) => {
              const xValue = row[xColumn];
              const yValue = row[yColumn];
              const hotel = row["hotel"];
              const arrivalYear = row["arrival_date_year"];

              if (
                (selectedOption === "" || hotel === selectedOption) &&
                (selectedOption2 === "" || arrivalYear === selectedOption2) &&
                xValue &&
                yValue
              ) {
                if (!monthData[xValue]) {
                  monthData[xValue] = { total: 0, count: 0 };
                }
                monthData[xValue].total += Number(yValue);
                monthData[xValue].count += 1;
              }
            });

            const monthOrder = [
              "January",
              "February",
              "March",
              "April",
              "May",
              "June",
              "July",
              "August",
              "September",
              "October",
              "November",
              "December",
            ];

            const months = [];
            const averages = [];

            Object.keys(monthData)
              .sort((a, b) => monthOrder.indexOf(a) - monthOrder.indexOf(b))
              .slice(0, 12) // Only keep the top 12 months
              .forEach((month) => {
                months.push(month);
                const avg = monthData[month].total / monthData[month].count;
                averages.push(avg);
              });

            setData({
              labels: months,
              datasets: [
                {
                  label: `ADR (Average Daily Rate)`,
                  data: averages,
                  fill: false,
                  backgroundColor: "#36A2EB",
                  borderColor: "rgba(66, 165, 245, 1)",
                  borderWidth: 1,
                },
              ],
            });

            setIsLoading(false); // Hide loader when data is ready
          },
        });
      });
  }, [selectedOption, selectedOption2, xColumn, yColumn, setIsLoading]);

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      title: {
        display: true,
        text: `ADR by Month`,
        font: { size: 15 },
      },
      tooltip: {
        callbacks: {
          label: function (context) {
            let label = context.dataset.label || "";
            if (label) {
              label += ": ";
            }
            label += context.raw.toFixed(2);
            return label;
          },
        },
      },
      legend: { display: true, position: "top" },
    },
    scales: {
      x: {
        title: {
          display: true,
          text: "Month",
        },
      },
      y: {
        title: {
          display: true,
          text: `ADR`,
        },
      },
    },
  };

  return (
    <div style={{ height: "245px", marginLeft: "12%", marginTop: "-15px", backgroundColor: 'rgb(243,244,245)' }}>
      <Line data={data} options={options} style={{ width: "350px" }} />
    </div>
  );
};

export default DynamicLineChart;