import React, { useEffect, useState } from "react";
import Papa from "papaparse";

const Slicer = ({ onOptionChange, isLoading, setIsLoading }) => {
  const [allOptions, setAllOptions] = useState([]);

  useEffect(() => {
    setIsLoading(true); 
    fetch("/cleaned_hotel_bookings.csv")
      .then((response) => response.text())
      .then((csvData) => {
        Papa.parse(csvData, {
          header: true,
          complete: (results) => {
            const optionSet = new Set();

            results.data.forEach((row) => {
              const option = row["hotel"];
              if (option) {
                optionSet.add(option);
              }
            });

            const sortedOptions = [...optionSet].sort((a, b) =>
              a.localeCompare(b)
            );

            setAllOptions(sortedOptions);
            setIsLoading(false);
          },
        });
      });
  }, [setIsLoading]);

  return (
    <div
      style={{ marginBottom: "20px", marginTop: "15px", marginLeft: "10px" }}
    >
      <h2 style={{ marginLeft: "35px", fontSize: "20px" }}>Hotel</h2>
      <select
        onChange={(e) => {
          setIsLoading(true); 
          onOptionChange(e); 
        }}
        style={{
          padding: "5px",
          fontSize: "10px",
          width: "8%",
          marginLeft: "10px",
        }}
      >
        <option value="">All</option>
        {allOptions.map((option, index) => (
          <option key={index} value={option}>
            {option}
          </option>
        ))}
      </select>
    </div>
  );
};

export default Slicer;
