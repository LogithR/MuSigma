import React, { useEffect, useState } from "react";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import Papa from "papaparse";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const ClusteredColumnChart = ({
  selectedOption,
  selectedOption2,
  xColumn,
  setIsLoading,
}) => {
  const [data, setData] = useState({ labels: [], datasets: [] });

  useEffect(() => {
    setIsLoading(true); 
    fetch("/cleaned_hotel_bookings.csv")
      .then((response) => response.text())
      .then((csvData) => {
        Papa.parse(csvData, {
          header: true,
          complete: (results) => {
            const aggregatedData = {};

            // results.data.forEach((row) => {
            //   const xValue = row['market_segment'] ; // Use the passed xColumn prop
            //   const option = row["hotel"];
            //   const option2 = row["arrival_date_year"];


            results.data.forEach((row) => {
                // Check if the row's 'is_canceled' value is 0
                if (row['is_canceled'] > 0) {
                  const xValue = row['market_segment']; // Use the passed xColumn prop
                  const option = row["hotel"];
                  const option2 = row["arrival_date_year"];  

              // Apply the filters for selectedOption and selectedOption2
              if (
                (selectedOption === "" || option === selectedOption) &&
                (selectedOption2 === "" || option2 === selectedOption2) &&
                xValue
              ) {
                if (!aggregatedData[xValue]) {
                  aggregatedData[xValue] = 0;
                }
                aggregatedData[xValue] += 1; // Increment the count for this xValue
              }
            }});

            const labels = Object.keys(aggregatedData);
            labels.sort((a, b) => a.localeCompare(b)); // Sort the labels alphabetically

            const datasets = [
              {
                label: "No of Bookings Cancelled",
                data: labels.map((label) => aggregatedData[label] || 0),
                backgroundColor: "#36A2EB",
                borderColor: "rgba(66, 165, 245, 1)",
                borderWidth: 1,
              },
            ];

            setData({
              labels: labels,
              datasets: datasets,
            });
            setIsLoading(false); // Hide loader when done
          },
        });
      });
  }, [selectedOption, selectedOption2, xColumn, setIsLoading]);

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      title: {
        display: true,
        text: `Cancellation by Market Segment`, // Dynamically show xColumn as title
        font: { size: 15 },
      },
      tooltip: {
        callbacks: {
          label: function (context) {
            let label = context.dataset.label || "";
            if (label) {
              label += ": ";
            }
            label += context.raw;
            return label;
          },
        },
      },
      legend: { display: true, position: "top" },
    },
    scales: {
      y: {
        title: {
          display: true,
          text: "No of Bookings Cancelled",
        },
        beginAtZero: true,
      },
    },
  };

  return (
    <div
      style={{
        height: "245px",
        marginLeft: "5px",
        marginTop: "-15px",
        backgroundColor: "rgb(243,244,245)",
      }}
    >
      <Bar data={data} options={options} style={{ width: "410px" }} />
    </div>
  );
};

export default ClusteredColumnChart;
