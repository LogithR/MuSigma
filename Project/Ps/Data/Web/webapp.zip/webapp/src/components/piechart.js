import React, { useEffect, useState } from "react";
import { Pie } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";
import Papa from "papaparse";

ChartJS.register(ArcElement, Tooltip, Legend);

const PieChart = ({ selectedOption, selectedOption2, setIsLoading }) => {
  const [data, setData] = useState({ labels: [], datasets: [] });

  useEffect(() => {
    setIsLoading(true); // Start loader when data fetch begins
    fetch("/cleaned_hotel_bookings.csv")
      .then((response) => response.text())
      .then((csvData) => {
        Papa.parse(csvData, {
          header: true,
          complete: (results) => {
            const marketSegmentCount = {};

            results.data.forEach((row) => {
              const segment = row["market_segment"];

              if (
                (selectedOption === "" || row["hotel"] === selectedOption) &&
                (selectedOption2 === "" ||
                  row["arrival_date_year"] === selectedOption2)
              ) {
                if (segment) {
                  marketSegmentCount[segment] =
                    (marketSegmentCount[segment] || 0) + 1;
                }
              }
            });

            const labels = Object.keys(marketSegmentCount);
            const values = Object.values(marketSegmentCount);

            setData({
              labels: labels,
              datasets: [
                {
                  label: "Market Segment Distribution",
                  data: values,
                  backgroundColor: [
                    "#1E90FF",
                    "#4682B4",
                    "#5F9EA0",
                    "#00BFFF",
                    "#87CEEB",
                    "#4169E1",
                    "#6495ED",
                    "#00CED1",
                    "#00FFFF",
                    "#B0E0E6",
                  ],
                },
              ],
            });

            setIsLoading(false); // Stop loader after data is loaded
          },
        });
      });
  }, [selectedOption, selectedOption2, setIsLoading]);

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      title: {
        display: true,
        text: "Market Segmentation",
        font: { size: 15 },
      },
      tooltip: {
        callbacks: {
          label: function (context) {
            let label = context.label || "";
            if (label) {
              label += ": ";
            }
            label += context.raw;
            return label;
          },
        },
      },
      legend: {
        display: true,
        position: "right",
        labels: {
          boxWidth: 10,
        },
      },
    },
  };

  return (
    <div>
      <div
        style={{
          width: "280px",
          height: "250px",
          marginLeft: "12%",
          marginTop: "-14.8%",
          backgroundColor: "rgb(243,244,245)",
        }}
      >
        <Pie data={data} options={options} style={{ marginLeft: "6px" }} />
      </div>
    </div>
  );
};

export default PieChart;
