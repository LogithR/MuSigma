import React from "react";

const Loader = ({ waitingTime }) => {
  return (
    <div
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100vw",
        height: "100vh",
        backgroundColor: "rgba(211, 211, 211, 0.7)", // Light grey background
        zIndex: 1000, // Ensures the loader appears on top
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <div style={loaderContainerStyle}>
        <div style={spinnerStyle}></div>
        <div style={numberStyle}>{waitingTime}</div>
      </div>
    </div>
  );
};

// Container style for loader and number
const loaderContainerStyle = {
  position: "relative",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
};

// Spinner style
const spinnerStyle = {
  width: "50px",
  height: "50px",
  border: "6px solid rgba(0, 0, 0, 0.1)", // Light border
  borderTop: "6px solid #000", // Darker border for the spinning part
  borderRadius: "50%",
  animation: "spin 1s linear infinite", // Animation effect
};

// Number style (centered in the spinner)
const numberStyle = {
  position: "absolute",
  fontSize: "18px",
  color: "#000",
  fontWeight: "bold",
};

// Keyframes for the spin animation
const styles = `
@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
`;

document.head.insertAdjacentHTML(
  "beforeend",
  `<style>${styles}</style>`
);

export default Loader;
