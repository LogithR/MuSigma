import React, { useEffect, useState } from "react";
import Papa from "papaparse";

const KPICard = ({ selectedOption, selectedOption2 }) => {
  const [totalCancelled, setTotalCancelled] = useState(0);
  const [totalBookingChanges, setTotalBookingChanges] = useState(0);
  const [totalRepeatedGuests, setTotalRepeatedGuests] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetch("/cleaned_hotel_bookings.csv")
      .then((response) => response.text())
      .then((csvData) => {
        Papa.parse(csvData, {
          header: true,
          complete: (results) => {
            let cancelledCount = 0;
            let bookingChangesCount = 0;
            let repeatedGuestsCount = 0;

            results.data.forEach((row) => {
              const option = row["hotel"];
              const option2 = row["arrival_date_year"];

              if (
                (selectedOption === "" || option === selectedOption) &&
                (selectedOption2 === "" || option2 === selectedOption2)
              ) {
                if ((row["is_canceled"] > 0)) {
                  cancelledCount += 1;
                }

                if (parseInt(row["booking_changes"]) > 0) {
                  bookingChangesCount += 1;
                }

                if (row["is_repeated_guest"] === "1") {
                  repeatedGuestsCount += 1;
                }
              }
            });

            setTotalCancelled(cancelledCount);
            setTotalBookingChanges(bookingChangesCount);
            setTotalRepeatedGuests(repeatedGuestsCount);
            setIsLoading(false);
          },
        });
      });
  }, [selectedOption, selectedOption2]);

  if (isLoading) {
    return <div>Loading...</div>; // Display loading while data is being fetched
  }

  return (
    <div style={{ marginTop: "-26%",marginLeft: "-2px"}}>
      <div
        style={{
          border: "1px solid #ddd",
          borderRadius: "8px",
          width: "100px",
          marginTop: "60px",
          marginLeft: "20px",
          textAlign: "center",
          boxShadow: "0 2px 5px rgba(0, 0, 0, 0.1)",
          backgroundColor: "#006666",
        }}
      >
        <h3
          style={{
            fontSize: "16px",
            color: "white",
            margin: "0",
            fontWeight: "normal",
          }}
        >
          <span style={{ fontSize: "12px", fontWeight: "bold" }}>
            Cancelled
          </span>
        </h3>
        <hr
          style={{
            width: "98%",
            border: "1px solid white",
            margin: "5px auto",
          }}
        />
        <div
          style={{
            fontSize: "20px",
            color: "white",
            fontWeight: "bold",
            marginTop:'-5px',
            margin: "5px auto",
          }}
        >
          {totalCancelled}
        </div>
      </div>

      <div
        style={{
          border: "1px solid #ddd",
          borderRadius: "8px",
          width: "100px",
          marginTop: "10px",
          marginLeft: "20px",
          textAlign: "center",
          boxShadow: "0 2px 5px rgba(0, 0, 0, 0.1)",
          backgroundColor: "#006666",
        }}
      >
        <h3
          style={{
            fontSize: "16px",
            color: "white",
            margin: "0",
            fontWeight: "normal",
          }}
        >
          <span style={{ fontSize: "11px", fontWeight: "bold"}}>
            Booking Changes
          </span>
        </h3>
        <hr
          style={{
            width: "98%",
            border: "1px solid white",
            margin: "5px auto",
          }}
        />
        <div
          style={{
            fontSize: "20px",
            color: "white",
            fontWeight: "bold",
            marginTop:'-5px',
            margin: "5px auto",
          }}
        >
          {totalBookingChanges}
        </div>
      </div>

      <div
        style={{
          border: "1px solid #ddd",
          borderRadius: "8px",
          width: "100px",
          marginTop: "10px",
          marginLeft: "20px",
          textAlign: "center",
          boxShadow: "0 2px 5px rgba(0, 0, 0, 0.1)",
          backgroundColor: "#006666",
        }}
      >
        <h3
          style={{
            fontSize: "20px",
            color: "white",
            margin: "0",
            fontWeight: "normal",
          }}
        >
          <span style={{ fontSize: "11px", fontWeight: "bold" }}>
            Repeated Guests
          </span>
        </h3>
        <hr
          style={{
            width: "98%",
            border: "1px solid white",
            margin: "5px auto",
          }}
        />
        <div
          style={{
            fontSize: "20px",
            color: "white",
            fontWeight: "bold",
            marginTop:'-5px',
            margin: "5px auto",
          }}
        >
          {totalRepeatedGuests}
        </div>
      </div>
    </div>
  );
};

export default KPICard;
