import "./App.css";
import React, { useState } from "react";
import Header from "./components/header";
import Kpi from "./components/kpi";
import Slicer from "./components/slicer1";
import Slicer2 from "./components/slicer2";
import PieChart from "./components/piechart";
import ClusteredBarChart from "./components/clusteredbar";
import LineChart from "./components/linechart";
import ColumnChart from "./components/columnchart";
import ClusteredColumnChart from "./components/clusteredcolumn";
import Loader from "./components/loader";


function App() {
  const [selectedOption, setSelectedOption] = useState("");
  const [selectedOption2, setSelectedOption2] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleOptionChange = (e) => {
    setSelectedOption(e.target.value);
  };

  const handleOptionChange2 = (e) => {
    setSelectedOption2(e.target.value);
  };

  return (
    <div>
      <Header />

      {isLoading && <Loader/>} {/* Show loader when isLoading is true */}

      <Slicer onOptionChange={handleOptionChange}
       isLoading={isLoading}
       setIsLoading={setIsLoading} />

      <Slicer2 onOptionChange2={handleOptionChange2} 
       isLoading={isLoading}
       setIsLoading={setIsLoading}/>

      <PieChart
        selectedOption={selectedOption}
        selectedOption2={selectedOption2}
        setIsLoading={setIsLoading}
      />

      <ClusteredBarChart
        selectedOption={selectedOption}
        selectedOption2={selectedOption2}
        setIsLoading={setIsLoading}
      />

      <div style={{ display: "flex"}}>
        <LineChart
          selectedOption={selectedOption}
          selectedOption2={selectedOption2}
          xColumn="month"
          yColumn="adr"
          setIsLoading={setIsLoading}
        />

        <ColumnChart
          selectedOption={selectedOption}
          selectedOption2={selectedOption2}
          xColumn="lead_time"
          yColumn="No of Bookings"
          setIsLoading={setIsLoading}
        />

        <ClusteredColumnChart
          selectedOption={selectedOption}
          selectedOption2={selectedOption2}
          xColumn="lead_time"
          yColumn="No of Bookings"
          setIsLoading={setIsLoading}
        />
      </div>

      <Kpi selectedOption={selectedOption} selectedOption2={selectedOption2}
       setIsLoading={setIsLoading} />
    </div>
  );
}

export default App;
